from django.shortcuts import render
from django.http import HttpResponse
from .models import Data

# Create your views here.


def index(request):
    return render(request, 'index.html')


def gallery(request):
    return render(request, "gallery.html")


def admission(request):
    return render(request, "admission.html")


def academics(request):
    return render(request, "academics.html")


def contacts(request):
    return render(request, "contacts.html")


def onlineclass(request):
    vid = Data.objects.all()
    return render(request, "onlineclass.html", {'vid': vid})
