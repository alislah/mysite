from django.apps import AppConfig


class AlislahSiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'alislah_site'
